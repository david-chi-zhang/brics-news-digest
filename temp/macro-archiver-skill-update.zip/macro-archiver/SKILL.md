---
name: macro-archiver
description: Extract macroeconomic data from TradingEconomics and archive to annual documents with automatic date detection. Triggers on update macro data requests.
---

# Macro Economic Data Archiver

## Purpose

Automate extraction and archiving of macroeconomic data summaries from TradingEconomics into structured **annual documents** with **automatic date detection** from the extracted text.

Supports two output targets:
- **Local Markdown files** (`macro_data/{Country}_{Indicator}_{Year}.md`)
- **Feishu Wiki documents** (MacroData 2026 knowledge base, with parent-child hierarchy)

## Trigger Phrases

- "更新 [Country] [Indicator]"
- "update macro data"
- "extract economic data"

## Workflow

### Step 0: Ask User for Output Target

**在开始任何操作之前，必须先询问用户：**

```
请问您希望将数据写入哪里？
A) 本地 Markdown 文件（~/workspace/macro_data/）
B) 飞书文档（JVS 知识库）
```

**根据用户选择执行不同流程：**
- 选 A → 使用本地 Markdown 流程
- 选 B → 使用飞书文档流程

---

### Step 0.5: Check Cache & Validate (Token 优化)

**缓存策略**（节约 50-70% web_fetch token）：

1. **检查缓存**：读取 `temp/macro_cache/{Country}_{Indicator}.json`
   - 如果缓存存在且 <24 小时 → 使用缓存数据
   - 如果缓存不存在或过期 → 重新 fetch

2. **验证缓存**（防止 stale data，关键！）：
   ```python
   # Fetch 前 100 个字符对比
   fresh_head = web_fetch(url, maxChars=100)
   cached_head = cache[country][indicator].get('head_100_chars')
   
   if fresh_head == cached_head:
       # 数据未变，使用缓存
       use_cache = True
   else:
       # 数据已更新，重新 fetch 完整内容
       use_cache = False
   ```

3. **更新缓存**：
   ```json
   {
     "country": "US",
     "indicator": "PMI",
     "fetched_at": "2026-03-20T15:00:00+08:00",
     "head_100_chars": "The S&P Global US Composite PMI dropped to 51.9...",
     "data": { ... }
   }
   ```

---

### Step 1: Parse Request

- **Country**: US, EuroArea, Japan, SouthAfrica, Bangladesh, Global, China
- **Indicator**: GDP, PMI, Inflation, etc.
- **Year**: Current year (e.g., 2026)

---

### Step 2: Determine Target Document

```python
year = datetime.now().year

# Local Markdown
target_doc = f"macro_data/{Country}_{Indicator}_{year}.md"

# Feishu Wiki
wiki_space_id = "7619253034769583063"  # MacroData 2026 knowledge base

# Parent: Country-Year index (e.g., "US - 2026")
parent_doc = f"{Country} - {year}"

# Child: Indicator document (e.g., "US - PMI - 2026")
child_doc = f"{Country} - {Indicator} - {year}"
```

---

### Step 3: Extract Data (带缓存优化)

```python
# 伪代码流程
cache_file = f"temp/macro_cache/{Country}_{Indicator}.json"

if os.path.exists(cache_file):
    cache = json.load(open(cache_file))
    if is_cache_fresh(cache):  # <24 hours
        # 验证缓存：fetch 前 100 字符对比
        fresh_head = web_fetch(url, maxChars=100)
        if fresh_head == cache['head_100_chars']:
            data = cache['data']  # 使用缓存
            skip_full_fetch = True

if not skip_full_fetch:
    data = web_fetch(url, extractMode='text', maxChars=1500)
    # 更新缓存
    update_cache(cache_file, data)
```

---

### Step 4: Detect Date from Summary

**从提取的段落中自动识别时间**，支持以下格式：

| 文本模式 | 识别结果 | 示例 |
|---------|---------|------|
| "in February 2026" | 2026-02 | "PMI fell to 51.6 in February 2026" |
| "in Q4 2025" | 2025-12 | "GDP grew 0.3% in Q4 2025" → 季度最后月份 |
| "in January" | 当前年份 -01 | 结合上下文推断年份 |
| "released on 2026-02-15" | 2026-02 | 发布日期 |
| "February reading" | 2026-02 | 当前年份 |

**日期识别脚本**：
```bash
python3 scripts/detect_date.py "<summary paragraph>"
```

**返回**：`YYYY-MM` 格式

---

### Step 5: Write to Document (Token 优化)

#### Step 5.1: Ensure Parent Index Exists (Feishu only)

**飞书知识库层级结构**：
```
MacroData 2026 Knowledge Base
├── Macro - 宏观经济数据索引 (root)
├── US - 2026 (parent)
│   ├── US - GDP - 2026 (child)
│   ├── US - PMI - 2026 (child)
│   └── US - Inflation - 2026 (child)
├── China - 2026 (parent)
│   ├── China - GDP - 2026 (child)
│   └── ...
```

**创建/检查父文档**：
```python
# 1. 搜索是否已存在父文档
parent_node = search_wiki_node(f"{Country} - {year}")

if not parent_node:
    # 2. 创建父文档（索引页面）
    parent_node = create_wiki_doc(
        title=f"{Country} - {year}",
        parent_node_token="Nku3wbMnTigBAikD0wAcj5bLnZe",  # Macro index
        content=generate_index_template(Country, year)
    )
```

**索引文档模板**：
```markdown
# {Country} - {Year}

## 📊 经济指标数据

### GDP
- [GDP](node_token_gdp)

### PMI
- [Composite PMI](node_token_pmi_composite)
- [Manufacturing PMI](node_token_pmi_manufacturing)
- [Services PMI](node_token_pmi_services)

### Inflation
- [CPI](node_token_cpi)
- [PPI](node_token_ppi)

---

*最后更新：{date}*
```

---

#### Step 5.2: Write to Child Document

**Option A: Local Markdown**

```markdown
# {Country} - {Indicator} - {Year}

## {Indicator}

### Composite PMI

**2026-02**. The S&P Global US Composite PMI dropped to 51.9 in February...

**2026-01**
Previous data paragraph...

---

*数据来源：Trading Economics | 更新时间：2026-03-20*
```

**Option B: Feishu Wiki (Child Document)**

```python
# 1. 确保子文档存在
child_node = search_wiki_node(f"{Country} - {Indicator} - {year}")

if not child_node:
    # 创建子文档，设置父节点
    child_node = create_wiki_doc(
        title=f"{Country} - {Indicator} - {year}",
        parent_node_token=parent_node['node_token'],
        content=f"# {Country} - {Indicator} - {year}\n\n## {Indicator}\n\n"
    )

# 2. Append 新数据到子文档末尾
feishu_update_doc:
  doc_id: child_node['obj_token']
  mode: append
  markdown: |
    **2026-02**
    [Summary paragraph]
```

**Rules:**
- Never overwrite existing data
- If same month exists → Append as new paragraph
- Preserve all existing months' data
- **月份格式**：`**YYYY-MM**. `（黑体字 + 句点 + 空格，然后接正文）
- **不使用空占位符**（如 "*No data available yet*"），文档只包含实际数据
- **飞书文档必须设置父子关系**，保持知识库整洁

---

### Step 6: No Placeholder Policy (Token 优化)

**文档中不保留空占位符**：

❌ **旧格式**（浪费 token）：
```markdown
### Composite PMI
#### 2026-01
*No data available yet.*
#### 2026-02
*No data available yet.*
```

✅ **新格式**（只包含实际数据）：
```markdown
### Composite PMI
**2026-02**. The S&P Global US Composite PMI dropped to 51.9 in February...
```

**好处：**
- 文档更简洁（减少 60-80% 字符）
- 读取/写入 token 大幅减少
- 避免维护占位符的开销

---

## Token Efficiency

| Method | Chars/Page | Savings |
|--------|-----------|---------|
| Unrestricted | ~4,000 | - |
| Optimized | ~750 | ~80% |
| **With Cache + Append + Annual** | ~100 | **~97%** |

---

## Scripts

- `scripts/extract_macro_data.py` - 提取工具
- `scripts/detect_date.py` - 日期识别工具
- `scripts/cache_utils.py` - 缓存管理工具
- `scripts/wiki_hierarchy.py` - 飞书层级管理工具（新增）

---

## References

- `references/url-library-template.json` - URL 模板
- `references/document-structure-template.md` - 文档结构模板
- `references/date-patterns.md` - 日期识别规则详情
- `references/indicator-hierarchy.json` - 指标层级定义（新增）

---

## Feishu Wiki Configuration

**Knowledge Base**: MacroData 2026
**Space ID**: `7619253034769583063`
**Wiki URL**: https://www.feishu.cn/wiki/BSCIwW224iuApuktP2UcJaO7nci (US - 2026)

**Document Hierarchy**:
```
Macro - 宏观经济数据索引 (root)
├── {Country} - {Year} (parent)
│   ├── {Country} - GDP - {Year} (child)
│   ├── {Country} - PMI - {Year} (child)
│   ├── {Country} - Inflation - {Year} (child)
│   └── ...
```

**Supported Countries**:
| Country | Emoji | Parent Doc | Child Doc Example |
|---------|-------|------------|-------------------|
| Global | 🌍 | Global - 2026 | Global - Trade - 2026 |
| China | 🇨🇳 | China - 2026 | China - GDP - 2026 |
| US | 🇺🇸 | US - 2026 | US - PMI - 2026 |
| Japan | 🇯🇵 | Japan - 2026 | Japan - GDP - 2026 |
| EuroArea | 🇪🇺 | EuroArea - 2026 | EuroArea - PMI - 2026 |
| Bangladesh | 🇧🇩 | Bangladesh - 2026 | Bangladesh - GDP - 2026 |

**Indicator Hierarchy** (for index doc):
```json
{
  "GDP": {
    "type": "single"
  },
  "PMI": {
    "type": "group",
    "sub_indicators": ["Composite PMI", "Manufacturing PMI", "Services PMI"]
  },
  "Inflation": {
    "type": "group",
    "sub_indicators": ["CPI", "PPI", "Core Inflation"]
  },
  "Real Sector": {
    "type": "group",
    "sub_indicators": ["Industrial Production", "Retail Sales", "Consumer Confidence", "Unemployment"]
  },
  "Monetary Policies": {
    "type": "group",
    "sub_indicators": ["Central Bank Policy Rate", "Central Bank Asset Growth"]
  }
}
```

---

## Example

**User:** "更新美国 PMI"

**Agent:**
1. **Ask user**: "请问您希望将数据写入哪里？A) 本地 Markdown 文件 B) 飞书文档"
2. User selects: B (Feishu)
3. **Check cache**: Read `temp/macro_cache/US_PMI.json`
4. **Validate cache**: Fetch first 100 chars, compare with cache
   - If match → Use cached data (skip full fetch)
   - If mismatch → Full fetch and update cache
5. **Determine docs**:
   - Parent: "US - 2026" (index)
   - Child: "US - PMI - 2026"
6. **Ensure parent exists**: Create "US - 2026" if needed
7. **Ensure child exists**: Create "US - PMI - 2026" as child of parent
8. **Detect dates:**
   - Composite PMI: "dropped to 51.9 in February" → **2026-02**
   - Manufacturing PMI: "fell to 51.6 in February of 2026" → **2026-02**
   - Services PMI: "fell to 51.7 in February of 2026" → **2026-02**
9. **Write with append mode**: Append to child document
10. **Update parent index**: Add/update links to child docs
11. Report: "✅ US PMI data (February 2026) archived to Feishu Wiki: US - PMI - 2026"

---

## Error Handling

- **URL not found** → Ask user
- **Extraction fails** → Retry once
- **Doc missing** → Auto-create (local: create file, feishu: create wiki doc with parent)
- **Date detection fails** → Use current month as fallback, notify user
- **User not responded** → Wait for user to select output target
- **Cache validation fails** → Full fetch and update cache
- **Wiki hierarchy error** → Fallback to flat structure, notify user

---

## Date Detection Patterns

### Month Patterns
```
in January/February/March... → YYYY-MM
January/February reading → YYYY-MM
released in Month → YYYY-MM
Month 2026 → 2026-MM
```

### Quarter Patterns
```
in Q1/Q2/Q3/Q4 YYYY → YYYY-(03/06/09/12)
first/second/third/fourth quarter → YYYY-(03/06/09/12)
```

### Year Inference
- Explicit year mentioned → Use that year
- No year mentioned → Use current year
- "last month" → Current month - 1
- "previous month" → Current month - 1

---

## Year Transition

**当前年份**：2026

**自动检测**：
- 默认写入当前年份文档（US_PMI_2026.md）
- 如果用户指定年份，使用指定年份

**跨年份处理**：
- 当进入新年（2027 年 1 月）时，自动创建新年度文档
- 用户可手动指定：`更新美国 PMI 到 2027 年文档`

---

## 📋 Complete Knowledge Base Creation Guide (完整创建流程)

**重要**：创建新知识库时，必须严格按照以下步骤，确保层级结构正确。

### Phase 1: Create Knowledge Base (Space)

```python
# 1. 创建知识库
feishu_wiki_space:
  action: create
  name: "MacroData 2026"
  description: "宏观经济数据知识库（严格按 URL Library 结构）"

# 返回 space_id，后续所有操作使用此 ID
space_id = "7619253034769583063"  # 示例
```

### Phase 2: Create Parent Documents (Root Level)

**关键**：所有国家父文档必须在根目录（parent_node_token 为空字符串）

```python
# 2. 创建所有国家的父文档（索引页面）
parent_docs = [
    "US - 2026",
    "EuroArea - 2026",
    "Japan - 2026",
    "SouthAfrica - 2026",
    "Bangladesh - 2026",
    "Global - 2026"
]

for parent_title in parent_docs:
    feishu_create_doc:
      title: parent_title
      wiki_space: space_id
      # 不传 wiki_node 或 parent_node_token，确保在根目录
      markdown: generate_index_template(parent_title)

# 保存所有 parent_node_token 供后续使用
parent_tokens = {
    "US - 2026": "BSCIwW224iuApuktP2UcJaO7nci",
    "EuroArea - 2026": "HN9LwfdN3idQEgkRAvfcxg60nlf",
    "Japan - 2026": "OgK1wL1UnipoCckHafncde6enJg",
    "SouthAfrica - 2026": "PfvfwOf33iTMmHkPrOjc3viHnkd",
    "Bangladesh - 2026": "Kdu0wXF5kiJQTSkDa1hcVU3snbf",
    "Global - 2026": "ImM6wpSRDifLkTk6kGhcUj2InKe"
}
```

### Phase 3: Fetch Data (按 url_library.json)

```python
# 3. 严格按照 url_library.json 抓取数据
url_library = load_json("references/url-library-template.json")

for country, indicators in url_library.items():
    for category, sub_indicators in indicators.items():
        for indicator, url in sub_indicators.items():
            # 抓取数据
            data = web_fetch(url, maxChars=3000)
            # 保存到临时变量
            cache_data[f"{country}_{indicator}"] = data
```

### Phase 4: Create Child Documents

```python
# 4. 创建所有子文档
for country, indicators in url_library.items():
    parent_token = parent_tokens[f"{country} - 2026"]
    
    for category, sub_indicators in indicators.items():
        for indicator, url in sub_indicators.items():
            data = cache_data[f"{country}_{indicator}"]
            
            # 创建子文档
            child_doc = feishu_create_doc:
              title: f"{country} - {indicator} - 2026"
              wiki_space: space_id
              markdown: format_indicator_data(country, indicator, data)
            
            # 保存 child_node_token
            child_tokens[f"{country}_{indicator}"] = child_doc['node_token']
```

### Phase 5: Move Child Documents to Parents

```python
# 5. 将所有子文档移动到对应父文档下
for country, indicators in url_library.items():
    parent_token = parent_tokens[f"{country} - 2026"]
    
    for category, sub_indicators in indicators.items():
        for indicator in sub_indicators.keys():
            child_token = child_tokens[f"{country}_{indicator}"]
            
            feishu_wiki_space_node:
              action: move
              node_token: child_token
              space_id: space_id
              target_parent_token: parent_token
```

### Phase 6: Update Parent Documents with Links

```python
# 6. 更新所有父文档，添加子文档链接
for country, indicators in url_library.items():
    parent_token = parent_tokens[f"{country} - 2026"]
    
    # 生成带链接的索引内容
    index_content = generate_index_with_links(country, indicators, child_tokens)
    
    feishu_update_doc:
      doc_id: parent_token
      mode: overwrite
      markdown: index_content
```

---

## 📊 Document Structure Summary

**Parent Documents (6 个，根目录)**:
- US - 2026 (11 children)
- EuroArea - 2026 (9 children)
- Japan - 2026 (9 children)
- SouthAfrica - 2026 (6 children)
- Bangladesh - 2026 (1 child)
- Global - 2026 (5 children)

**Total**: 41 child documents

**Format**:
- Month format: `**YYYY-MM**. ` (bold + period + space)
- No placeholders (only actual data)
- Parent-child hierarchy strictly maintained

---

## 🔧 Quick Reference Commands

```bash
# List all documents in space
feishu_wiki_space_node:
  action: list
  space_id: "7619253034769583063"
  page_size: 50

# Move document to parent
feishu_wiki_space_node:
  action: move
  node_token: <child_node_token>
  space_id: <space_id>
  target_parent_token: <parent_node_token>

# Update parent with links
feishu_update_doc:
  doc_id: <parent_node_token>
  mode: overwrite
  markdown: |
    # Country - 2026
    ## 📊 经济指标数据
    - [Indicator](https://www.feishu.cn/wiki/<child_node_token>)
```
